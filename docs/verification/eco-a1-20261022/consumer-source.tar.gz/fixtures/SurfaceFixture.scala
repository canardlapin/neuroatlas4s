package consumer
import neuroatlas4s.*
import neurosurf4s.surface.{Hemisphere as H, *}

object SurfaceFixture:
  val mesh = TriangleMesh.fromRows(Vector(Vector(0d, 0d, 0d), Vector(1d, 0d, 0d), Vector(0d, 1d, 0d)), Vector((0, 1, 2)))
  def geometry(side: H): SurfaceGeometry = SurfaceGeometry(mesh, side, SurfaceKind.Pial)
  val ref = AtlasRef.surface("consumer", "Bilateral", SpaceId.FsAverage6, SpaceId.FsAverage6, confidence = Confidence.Exact)
  val regions = RegionIndex(Vector(AtlasRegionMetadata(RegionId(20), "Right"), AtlasRegionMetadata(RegionId(10), "Left")))
  def labels(side: H, id: Int): LabeledSurface = LabeledSurface.fromIndexed(geometry(side), Vector(VertexId(0), VertexId(1)), Vector(id, id), Vector(LabelInfo(id, id.toString)))
  def atlas(): SurfaceAtlas = SurfaceAtlas.fromLabeledSurfaces(ref, regions, labels(H.Left, 10), labels(H.Right, 20))
