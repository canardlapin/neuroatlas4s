package consumer
import neuroatlas4s.*
import neurosurf4s.surface.{Hemisphere as H, VertexId}

class SurfaceSuite extends munit.FunSuite:
  test("bilateral membership preserves metadata order, background and exact vertex fibers"):
    val atlas = SurfaceFixture.atlas()
    val r = atlas.realization
    assertEquals(r.parcelAssignment.from.size, 6)
    assertEquals(r.displayOrder.indices.map(index => r.metadata(index).id).toVector, Vector(RegionId(20), RegionId(10)))
    assertEquals(r.region(RegionId(10)).get.ordinalsInDomainOrder.toVector, Vector(0, 1))
    assertEquals(r.region(RegionId(20)).get.ordinalsInDomainOrder.toVector, Vector(3, 4))
    assertEquals(atlas.labelIdAt(H.Left, VertexId(2)), None)
    assertEquals(atlas.labelIdAt(H.Right, VertexId(0)), Some(RegionId(20)))
    assertEquals(atlas.left.labels.toVector, Vector(10, 10))
    assertEquals(r.neuropublishProjection.assignments.map(_.targetOrdinals), Vector(Vector(1, 1, -1), Vector(0, 0, -1)))
