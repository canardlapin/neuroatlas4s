package consumer
import neuroatlas4s.*
import neuroim4s.image.SpatialPoint

class RouteSuite extends munit.FunSuite:
  test("public mixed route preserves forward oracle and discloses planned surface execution"):
    val result = SpaceTransforms.transformCoords(Vector(SpatialPoint(10d, -20d, 35d)), SpaceId.MNI305, SpaceId.MNI152).toOption.get.head
    assertEqualsDouble(result.x, 10.694, .01)
    assertEqualsDouble(result.y, -18.406, .01)
    assertEqualsDouble(result.z, 36.139, .01)
    val plan = VolumeSurfaceTransformPlan.volumeToSurface(SpaceId.MNI152NLin6Asym, SpaceId.FsAverage).toOption.get
    assertEquals(plan.status, TransformStatus.Planned)
    assert(plan.steps.exists(_.kind == TransformKind.VolToSurf))
    assert(!plan.isExecutable)
